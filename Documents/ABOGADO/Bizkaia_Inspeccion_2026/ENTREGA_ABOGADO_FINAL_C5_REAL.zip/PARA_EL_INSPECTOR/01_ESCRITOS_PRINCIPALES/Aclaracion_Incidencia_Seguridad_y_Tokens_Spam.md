# ANEXO TÉCNICO: INCIDENCIA DE SEGURIDAD (HACKEO) Y EXCLUSIÓN DE TOKENS SPAM (WALLET PRINCIPAL 0x5247...)

**Contribuyente:** Borja Fernández Angulo  
**Expediente:** Órgano de Inspección - Departamento de Hacienda y Finanzas de la Diputación Foral de Bizkaia  
**Wallet Principal Afectada:** `0x5247299421A3Ff724c41582E5A44c6551d135Fd3` (Nombre asociado: `borja.moskv.eth`)  

---

### 1. Antecedentes y Compromiso de Seguridad (Hackeo)
Se hace constar ante la Inspección de Tributos que la Wallet Principal del contribuyente (`0x5247...5Fd3`) sufrió una **incidencia de seguridad crítica (compromiso de clave privada / hackeo) a finales de la anualidad 2023**.

A partir de dicho período, la dirección pública ha sido objeto de acceso no autorizado y manipulación por parte de diversos agentes maliciosos (*hackers*). Este incidente invalida el control exclusivo del contribuyente sobre dicha dirección de red y explica la aparición de transacciones anómalas, interacciones con contratos inteligentes desconocidos y depósitos no consentidos de activos.

### 2. Mecanismo de Inyección de Tokens Spam (Dusting Attacks)
Tras la pérdida de control de la wallet a finales de 2023, la cuenta ha sido utilizada por los atacantes para recibir y albergar decenas de tokens fraudulentos, técnicamente denominados **tokens basura o spam (Dusting / Airdrop scam)**. 

Este mecanismo malicioso consiste en transferir cantidades masivas de un token creado de forma artificial a wallets comprometidas. A menudo, estos tokens reflejan cotizaciones nocionales elevadas en exploradores multichain (como Etherscan, DeBank o Zerion) debido al emparejamiento con pools de liquidez manipulados o cerrados unilateralmente por los creadores. No obstante, **carecen por completo de liquidez real, profundidad de mercado o valor de realización**.

### 3. Caso de Estudio: Token Falso "Trump Project 2025 (MAGA)"
El ejemplo más flagrante de esta manipulación técnica que figura actualmente en el portafolio on-chain de la wallet principal (visible en la sección *Multichain Assets* de Etherscan) es el siguiente:

*   **Activo:** Trump Project 2025 (MAGA)
*   **Balance nominal:** 490.470 tokens
*   **Valoración teórica en explorador:** ~$30.761,58 USD (Cotización teórica de ~$0,062719)
*   **Realidad Técnica y Financiera:** 
    1.  **Origen ilícito:** Este token fue inyectado de forma maliciosa por uno de los atacantes que comprometió la wallet a finales de 2023. El contribuyente no ha adquirido, minteado, ni interactuado voluntariamente con este smart contract en ningún momento.
    2.  **Valor real de mercado = 0,00 €:** Se trata de un token scam sin pool de liquidez tradeable en ningún exchange descentralizado (DEX) regulado o líquido. Su venta o canje por dinero fiat (EUR) u otras criptomonedas con valor real (como ETH o USDT) es matemáticamente imposible.
    3.  **Acompañamiento:** Junto a este activo, se han registrado decenas de inyecciones de otros tokens "basura" de idéntica naturaleza nula (spam tokens).

### 4. Petición de Criterio Técnico a la Inspección
Por lo expuesto, se solicita a la Inspección de Tributos:

1.  **Exclusión de Base Imponible:** Que no se compute valor de mercado alguno para la posición "Trump Project 2025 (MAGA)" ni para el resto de tokens spam asociados a la wallet `0x5247...5Fd3` a efectos del **Impuesto sobre el Patrimonio** de los ejercicios 2023 y 2024. Su valor realizable a 31 de diciembre es estrictamente **0,00 €**.
2.  **Invalidez de Control Exclusivo:** Que se reconozca que la wallet principal se encuentra en estado comprometido desde finales de 2023, desvinculando al contribuyente de cualquier flujo de red posterior a la fecha del hackeo que no sea plenamente atribuible a su actividad económica previa certificada.
3.  **Abandono Definitivo de Uso:** Que se tome constancia de que, pese a los esfuerzos técnicos de saneamiento (incluyendo la revocación del código de delegación EIP-7702 para limpiar el bytecode de la dirección), la exposición de la clave semilla inicial hace que el monedero sea inseguro de manera irreversible. El contribuyente ha cesado por completo y de forma definitiva cualquier uso de estas direcciones.

En Bilbao, a la fecha de presentación.
