# CONSULTA TRIBUTARIA ESCRITA (VERSIÓN MEJORADA C5-REAL)

**A LA DIRECCIÓN GENERAL DE HACIENDA DEL DEPARTAMENTO DE HACIENDA Y FINANZAS (DIPUTACIÓN FORAL DE BIZKAIA)**

**1. IDENTIFICACIÓN DEL CONSULTANTE**
- **Nombre:** [NOMBRE DEL CONTRIBUYENTE]
- **NIF:** [NIF]
- **Domicilio a efectos de notificaciones:** [DOMICILIO]

**2. DESCRIPCIÓN DE LOS HECHOS Y ANTECEDENTES TECNOLÓGICOS**
El consultante, residente fiscal en Bizkaia, ha operado durante los ejercicios 2021-2024 en una plataforma internacional de activos virtuales (*Rollbit*), radicada en jurisdicción no comunitaria (Curazao) y amparada nominalmente bajo una licencia de eGaming.

Más allá de los servicios de azar, la plataforma dispuso una infraestructura de mercado financiero extrabursátil (OTC) mediante la cual el consultante operó instrumentos complejos no regulados: **Contratos de Futuros Perpetuos sobre Criptoactivos**, con posibilidad de apalancamiento sintético (hasta x1000).

Como consecuencia de la liquidación forzosa (*margin call*) de las garantías depositadas ante variaciones abruptas en el mercado spot de los subyacentes (Bitcoin, Ethereum), el consultante ha soportado minoraciones patrimoniales consolidadas en forma de criptoactivos (aprox. 14 ETH).

Se constatan los siguientes vectores técnicos y jurídicos:
*   **Ausencia de Aleatoriedad Pura:** El resultado del contrato no depende del azar, sino de la cotización real y global de un activo subyacente. El mecanismo es equivalente a los Contratos por Diferencias (CFDs).
*   **Vacío Regulatorio y Naturaleza Extraterritorial:** La plataforma operaba al margen de los canales financieros tradicionales y la supervisión de la CNMV. Sin embargo, la calificación de las operaciones debe atender a su verdadera naturaleza jurídica y económica (sustancia sobre forma), consistiendo materialmente en la toma de posiciones de riesgo direccional sobre activos financieros.

**3. FUNDAMENTACIÓN NORMATIVA (NORMA FORAL 13/2013)**
Conforme al **artículo 42** de la NF 13/2013, del Impuesto sobre la Renta de las Personas Físicas, son ganancias y pérdidas patrimoniales las variaciones en el valor del patrimonio del contribuyente que se pongan de manifiesto con ocasión de cualquier alteración en la composición de aquél.

Por su parte, la Doctrina Administrativa asienta reiteradamente (vgr. Consultas DGT V0808-18, V1069-19) que el resultado de operaciones con CFDs u otros derivados sobre subyacentes financieros o criptoactivos, generan ganancias o pérdidas patrimoniales que deben integrarse en la **Base Imponible del Ahorro**.

**4. CUESTIÓN PLANTEADA**
Se formula la presente consulta a efectos de obtener seguridad jurídica vinculante sobre el siguiente extremo:

Considerando que el instrumento contratado responde a la naturaleza de un derivado financiero (operativa sobre la fluctuación de un subyacente sin entrega de este), y con independencia de que la plataforma proveedora actúe desde el extranjero, eluda la supervisión de la CNMV y opere bajo una licencia que no ampara formalmente servicios de inversión:

¿Se confirma que el impacto económico derivado de la liquidación de las garantías de dichos contratos constituye una **Pérdida Patrimonial** imputable a la **Base Imponible del Ahorro**, conforme a lo dispuesto en la Norma Foral 13/2013, habilitando su compensación con ganancias patrimoniales (u otros componentes de dicha base) del ejercicio y de los cuatro años siguientes?
