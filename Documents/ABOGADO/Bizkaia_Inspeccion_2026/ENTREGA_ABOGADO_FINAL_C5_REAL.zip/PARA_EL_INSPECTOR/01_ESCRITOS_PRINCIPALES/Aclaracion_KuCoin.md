# ACLARACIÓN OPERATIVA: EXCHANGE KUCOIN

**A la atención de Ricardo (Letrado) y la Inspección de Bizkaia:**

En relación con la aparición de un archivo CSV correspondiente al exchange internacional **KuCoin**, se efectúa la siguiente aclaración técnica para su inclusión en el expediente:

### 1. Naturaleza de la operativa
KuCoin no ha funcionado en ningún momento como plataforma de custodia de patrimonio a 31 de diciembre de los ejercicios inspeccionados, ni como rampa de salida a Fiat (cash-out). 

Su uso fue exclusivamente **transitorio y puente** (bridge) para adquirir tokens no listados en Binance (low-cap tokens) que requerían liquidez inmediata en momentos puntuales de 2021 y 2022.

### 2. Volumen de Operaciones (Aclaración del CSV)
El archivo CSV adjunto refleja un volumen operativo bruto de carácter menor:
*   **2021:** 2 compras (100 KCS y 500 USDC) por valor de **1.350 USDT** totales.
*   **2022:** 1 venta (100 KCS) por valor de **2.130 USDT**.
*   **2023:** 1 compra (0.5 ETH) por valor de **825 USDT**.
*   **2024:** 1 venta (0.5 ETH) por valor de **1.250 USDT**.
*   **Saldo Real Custodiado a 31/12 (todos los ejercicios):** **0,00 €**. Los fondos siempre fueron retirados de la plataforma inmediatamente tras la compra o la conversión.

### 3. Justificación de Ausencia Previa
Dado que el saldo a cierre de año siempre fue 0,00 € y KuCoin no emite informes fiscales anuales estandarizados como Binance, este exchange quedó fuera del radar de las declaraciones de patrimonio en años anteriores. Su inclusión ahora responde a un criterio de **transparencia total** ante la Inspección, aportando el CSV para demostrar que las entradas y salidas cuadran y no existe capital oculto en esta plataforma.
