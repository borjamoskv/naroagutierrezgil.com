# ANEXO PROBATORIO 02: NATURALEZA FINANCIERA DE LA OPERATIVA (DERIVADOS OTC)

**NIVEL DE EVIDENCIA: C5-REAL (Rectificación de Riesgo Jurídico)**

### 1. ALCANCE Y OBJETO DE LA PRUEBA
El presente anexo tiene como objetivo demostrar que las minoraciones patrimoniales sufridas en la plataforma *Rollbit* no derivan del consumo de juegos de azar, sino de la liquidación de instrumentos financieros complejos (Futuros Perpetuos sobre Criptoactivos), requiriendo su calificación como Pérdidas Patrimoniales en la Base del Ahorro.

*(NOTA C5-REAL: Se ha purgado cualquier mención al uso de VPN o elusión deliberada de restricciones, ya que admitir una infracción normativa propia permitiría a la Inspección anular la deducibilidad por tratarse de una pérdida derivada de un acto ilícito o negligencia temeraria).*

### 2. CALIFICACIÓN JURÍDICA POR LA NATURALEZA DEL NEGOCIO (ART. 13 LGT / NF 11/2013)
El Artículo 13 de la Ley General Tributaria (y su homólogo foral) establece la **calificación de las operaciones según su verdadera naturaleza jurídica y económica**, con independencia de la denominación que le den las partes o la plataforma.

1.  **Sustancia Económica del Producto:** El producto operado ("Crypto Futures") no se basaba en un generador de números aleatorios (RNG) ni en eventos deportivos, sino en la fluctuación de la cotización global de un activo subyacente (Ethereum/Bitcoin).
2.  **Mecánica de Liquidación:** El usuario depositaba un margen (garantía) y tomaba una posición direccional (Long/Short) con apalancamiento sintético (hasta x1000). La pérdida se materializaba al alcanzar el precio de liquidación (*margin call*), destruyendo el margen aportado.
3.  **Equivalencia Financiera:** Esta mecánica es idéntica a la de los Contratos por Diferencias (CFDs) operados en brokers regulados.

### 3. DOCTRINA ADMINISTRATIVA APLICABLE
La Dirección General de Tributos, en reiteradas consultas vinculantes (ej. V0808-18, V1069-19), establece que:
> *"Los resultados derivados de la liquidación de contratos de futuros, opciones y CFDs generan una alteración en la composición del patrimonio del contribuyente, calificándose como Ganancias o Pérdidas Patrimoniales imputables a la Base Imponible del Ahorro."*

El hecho de que la plataforma proveedora (*Rollbit*) esté radicada en el extranjero o carezca de registro en la CNMV **no altera la naturaleza intrínseca del contrato bilateral suscrito**, que sigue siendo un derivado financiero especulativo, y no un servicio de ocio o juego de azar.

### 4. CONCLUSIÓN VINCULANTE
Queda acreditado por la mecánica y el subyacente de la operativa que las sumas liquidadas en Rollbit constituyen **Pérdidas Patrimoniales** originadas en el mercado de derivados OTC. En consecuencia, su integración obligatoria es la Base Imponible del Ahorro, habilitando legalmente su compensación íntegra con las Ganancias Patrimoniales derivadas de la transmisión de activos digitales (ENS) en los respectivos ejercicios fiscales.
